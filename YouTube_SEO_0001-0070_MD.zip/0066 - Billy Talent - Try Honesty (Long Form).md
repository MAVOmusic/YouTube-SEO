# CO-0066 | Reviewed copy (2026-11-03)

> Copy the title, description, tags and proposed pin. Genre findings are internal.
> Historical viewer conversation visible; retain it.

## TITLE (54 characters)

```text
Try Honesty: Sean Michael Turrell directs Billy Talent
```

## DESCRIPTION (477 characters)

```text
Sean Michael Turrell directed Billy Talent's Try Honesty music video in 2003. Try Honesty features on the self-titled album; the band video is separate from this upload.

The game chart appears beside my bass performance.

🟢 Bring an early Billy Talent pick into Kick chat: https://kick.com/mavomusic
🟣 A separate Twitch chat receives the mirror: https://www.twitch.tv/mavomusic
💬 Share early Billy Talent memories on Discord; boosts are optional: https://discord.gg/ESGsGkN4j2
```

## TAGS (11 tags, 163/500 characters)

```text
billy talent, try honesty, billy talent try honesty, billy talent i, benjamin kowalewicz, jon gallant, alternative rock, pop punk, 2003, bass cover, rocksmith bass
```

## PINNED COMMENT (55 characters)

```text
Which early Billy Talent video would you revisit today?
```

## GENRE FINDINGS (internal - not for playlists)

Artist-level classifications from https://en.wikipedia.org/wiki/Billy_Talent; these do not establish that every genre describes this recording. See Band Info/Billy Talent/Register.md.

## CORRECT GENRES

- Alternative rock
- Punk rock
- Post-hardcore
- Pop punk
- Emo
