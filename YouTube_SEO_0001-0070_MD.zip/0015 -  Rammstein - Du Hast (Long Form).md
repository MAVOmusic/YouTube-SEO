# CO-0015 | Rewritten copy (Ver 4.17)

> Paste directly. Kick first, Twitch as mirror, Discord last. One URL each, no repeats.

## TITLE (56 characters)

```text
Du Hast and the wedding vow: Rammstein's industrial bass
```

## DESCRIPTION (487 characters)

```text
Du Hast was the second single from Rammstein's 1997 album Sehnsucht. Its lyrics draw on the wording of a wedding vow.

Use the chart as a guide and decide which section of this bass performance you would tackle first.

🟢 Tune in on Kick for a dose of industrial metal: https://kick.com/mavomusic
🟣 Twitch mirrors the broadcast for its own chat: https://www.twitch.tv/mavomusic
💬 Bring your Rammstein picks to Discord; support through a boost is appreciated: https://discord.gg/ESGsGkN4j2
```

## TAGS (15 tags, 207/500 characters)

```text
rammstein, du hast, rammstein du hast, sehnsucht, industrial metal, oliver riedel, ramstein, bass cover, bass play along, rocksmith bass, rocksmith 2014, 1997, neue deutsche harte, metal bass, till lindemann
```

## PINNED COMMENT (81 characters)

```text
Which Rammstein song would you choose for someone learning their first bass part?
```

## GENRE FINDINGS (internal)

Artist-level genres from https://www.wikiwand.com/en/Rammstein. The consistent artist list is not an assertion that this particular recording fits every genre. See Band Info/Rammstein/Register.md.

## CORRECT GENRES (playlist reference)

- Neue Deutsche Haerte
- Industrial metal
