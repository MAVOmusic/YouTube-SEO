# CO-0058 | Reviewed copy (2026-11-03)

> Copy the title, description, tags and pinned comment. Genre findings are internal.

## TITLE (62 characters)

```text
A Swedish king inspires The Lion From The North - Sabaton bass
```

## DESCRIPTION (476 characters)

```text
Sabaton say the story of Swedish king Gustavus Adolphus inspired The Lion From The North. It follows the instrumental Dominium Maris Baltici on their 2012 album Carolus Rex.

The Rocksmith chart is visible while I play bass.

🟢 Share a history-themed request over on Kick: https://kick.com/mavomusic
🟣 You can follow the mirror on Twitch: https://www.twitch.tv/mavomusic
💬 Discuss historical songs in Discord; thanks to those who choose to boost: https://discord.gg/ESGsGkN4j2
```

## TAGS (12 tags, 190/500 characters)

```text
sabaton, the lion from the north, sabaton the lion from the north, lion from the north, carolus rex, gustavus adolphus, gustav adolf, power metal, 2012, bass cover, rocksmith, rocksmith bass
```

## PINNED COMMENT (53 characters)

```text
Which historical figure deserves a song of their own?
```

## GENRE FINDINGS (internal - not for playlists)

Artist-level classifications from https://www.pressure-magazine.de/bandprofil/sabaton-266680/; these do not establish that every genre describes this recording. See Band Info/Sabaton/Register.md.

## CORRECT GENRES

- Power metal
- Heavy metal
