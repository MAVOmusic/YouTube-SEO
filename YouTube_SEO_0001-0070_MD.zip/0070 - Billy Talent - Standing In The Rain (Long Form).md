# CO-0070 | Reviewed copy (2026-11-03)

> Copy the title, description, tags and proposed pin. Genre findings are internal.

## TITLE (49 characters)

```text
Standing In The Rain | early Billy Talent on bass
```

## DESCRIPTION (433 characters)

```text
Standing in the Rain sits between River Below and Cut the Curtains on the 2003 self-titled Billy Talent album.

Bass playing and the Rocksmith chart share the screen in this take.

🟢 Suggest a three-song album run on Kick: https://kick.com/mavomusic
🟣 A mirror is available to the Twitch community: https://www.twitch.tv/mavomusic
💬 Compare album sequences via Discord; thanks to our community boosters: https://discord.gg/ESGsGkN4j2
```

## TAGS (14 tags, 224/500 characters)

```text
billy talent, standing in the rain, billy talent standing in the rain, billy talent i, jon gallant, benjamin kowalewicz, alternative rock, pop punk, 2003, bass cover, rocksmith bass, ben kowalewicz, jonathan gallant, ian dsa
```

## PINNED COMMENT (50 characters)

```text
Which three-song run on an album do you return to?
```

## GENRE FINDINGS (internal - not for playlists)

Artist-level genres from https://en.wikipedia.org/wiki/Billy_Talent. These are catalogue-wide classifications, not necessarily descriptions of this recording. See Band Info/Billy Talent/Register.md.

## CORRECT GENRES

- Alternative rock
- Punk rock
- Post-hardcore
- Pop punk
- Emo
