# CO-0008 | Rewritten copy (Ver 4.17)

> Paste directly. Kick first, Twitch as mirror, Discord last. One URL each, no repeats.

## TITLE (48 characters)

```text
The bittersweet side of Green Day: X-Kid on bass
```

## DESCRIPTION (523 characters)

```text
Green Day released a video showing X-Kid playing on a cassette tape in 2012. The song appears on Tre and was inspired by the loss of a friend.

This bass play along shows the Rocksmith chart. Follow the part and listen to the contrast between the music and the subject of the lyrics.

🔴 Visit Kick for live bass music: https://kick.com/mavomusic
🟣 You can also watch its Twitch mirror: https://www.twitch.tv/mavomusic
💬 Post a Green Day request in Discord; thank you if you choose to boost us: https://discord.gg/ESGsGkN4j2
```

## TAGS (16 tags, 183/500 characters)

```text
green day, x-kid, x kid, tre, mike dirnt, punk rock, pop punk, bass cover, bass play along, rocksmith bass, rocksmith 2014, 2012, bass guitar, punk bass, green day rocksmith, greenday
```

## PINNED COMMENT (93 characters)

```text
Does knowing the story behind X-Kid change how you hear it, or did the music reach you first?
```

## GENRE FINDINGS (internal)

Artist-level genres from https://en.wikipedia.org/wiki/Green_Day. The same artist list is used for all this artist's uploads as requested; it is not a claim that this specific recording sounds like every listed genre. See Band Info/Green Day/Register.md.

## CORRECT GENRES (playlist reference)

- Punk rock
- Pop punk
- Alternative rock
- Skate punk
- Power pop
