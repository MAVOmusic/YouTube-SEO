================================================================================
MAVOmusic (@mavomusicyt) - PER-CHAT ATTACHMENT KIT - VER 2.65 (2026-08-07)
================================================================================
Paste the CONTENTS of this folder at the start of every new chat. The platform
accepts TEXT FILES ONLY (images excepted) - .py/.md/.xlsx/.zip cannot be
pasted, which is why every script and package is serialized inside the
Recovery_*.txt containers below. NEW CHATS NEED NO ZIP - this kit is fully
self-sufficient (the ZIP files are MAVO-side local backups only).

RESTORE ORDER (the new chat's AI does this):
  0. VISION SELF-CHECK FIRST (00_VISION_CHECK_FIRST.txt / CONTEXT &28):
     confirm the chat can read images. If NO vision -> STOP, tell MAVO plainly,
     do NOT restore. If YES -> say "Vision confirmed" and continue.
  1. Read 01_CONTEXT_BLOCK.txt            -> ruleset Sections 12-28 + CURRENT STATUS
  2. Read 07_MAVO_VERSION_LOG.txt         -> project state (Ver 1.02 -> 2.65)
  3. Decode 02_Recovery_Scripts.txt       -> PY/*.py (11 tools) + verify.sh
  4. Decode 03-06_Recovery_Data_a-d.txt   -> bands/ (304 packages, 76/76/76/76)
  5. python3 PY/generate_track_history.py -> rebuilds CSV + XLSX (304 records)
  6. bash verify.sh                       -> two-tier gate (verify.py +
     diversity_guard.py) must print ALL GATES GREEN before any work ships.

FILE MANIFEST (kit files 00-22):
  00_PASTE_PRIORITY.txt ............... paste triage (tiered version of the steps above)
  00_VISION_CHECK_FIRST.txt ........... step-0 vision gate
  01_CONTEXT_BLOCK.txt ................ master ruleset (VER 2.65 ACTIVE)
  02_Recovery_Scripts.txt ............. base64: all 11 PY tools + verify.sh
  03_Recovery_Data_a.txt .............. base64: packages 001-076
  04_Recovery_Data_b.txt .............. base64: packages 077-152
  05_Recovery_Data_c.txt .............. base64: packages 153-228
  06_Recovery_Data_d.txt .............. base64: packages 229-304
  07_MAVO_VERSION_LOG.txt ............. per-version audit narratives (Ver 1.02-2.65)
  08_README_FIRST.txt ................. this file
  09_Analytics_Of_Songs_0001_0050.txt . Studio screenshot extractions 0001-0050 (CLOSED)
  10_Analytics_Of_Songs_0051_0100.txt . songs 0051-0100 (filed through 0069)
  11_Analytics_Of_Songs_0101_0150.txt . songs 0101-0150 (open)
  12_Matched_Shorts_To_Cross_Check.txt  154 matched alternate cuts <-> 81 canonical targets
  13_Master_Long_Form_Repository_0001_0702.txt
  14_Master_Shorts_Repository.txt ..... 2,460 Shorts rows (source of truth)
  15_Backlog_Duplicate_Shorts_Audit_0151_2460.txt ... duplicate-cluster velocity data
  16_Master_Under_Review_Audit.txt .... THE cleaned Under Review master (flags 0-0-0-0)
  17_Shorts_ID_Whitelist_0133_2460.txt  approved Shorts IDs (plain 4-digit)
  18_MAVO_PROJECT_LOG.txt ............. long-form project history + carry-over bullets
  19_Pipeline_Notes_2026-08.txt ....... re-record program (0151+ LF+SF), lyrics-on-screen,
                                        SEO backlog (<10%, post-shadowban), wave grid
  20_Blocked_Claims_Register.txt ...... 0081 Complicated (SME/Arista) global-block register
  21_Repurposing 0051 - 0100.txt ...... tier boards / hook ladder / rosters (live working)
  22_Repurposing 0001 - 0050.txt ...... closed boards, first range

NEXT-CHAT POINTERS (VER 2.65):
  - Recheck queue parked at 0070: 0070-0083 shipped with ZERO panel submissions
    (incl. legacy-mirror pictures) -> matured multi-week day-N reads expected first.
  - Wave grid: 0084-0089 @ 06-08, 0090-0095 @ 07-08, 0096-0100 @ 08-08 (md dates
    already renamed to match). 0091 = Arista-claims watch (Arista blocked 0081).
  - Mirror completion DONE at 2.65: 107 new SHORT-ONLY-MATCH stub records
    (corpus 197 -> 304 packs); SF packs get prebuilt per batch at re-record phase.
  - Legacy SEO revamp resumes POST-SHADOWBAN using TXT/Titles, Descriptions,
    Tags, Pinned_Comments assets.
  - User live-fix queue (hashtag swaps on live videos): 0062 (both), 1719 (SF).

If any of these are missing from a chat paste, the AI MUST ASK for them before
touching tags, analytics, or Under Review flags (Section 22/23/24 rules).
These are COPIES; canonical homes: workspace root, TXT/, Under Review/, Whitelist/.
================================================================================
